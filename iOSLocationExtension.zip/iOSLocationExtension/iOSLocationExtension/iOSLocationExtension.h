//
//  iOSLocationExtension.h
//  iOSLocationExtension
//
//  Created by Marcus Andersson on 30/03/16.
//  Copyright © 2016 KjeMar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FlashRuntimeExtensions.h"
#import <CoreLocation/CoreLocation.h>
#import <EstimoteSDK/EstimoteSDK.h>

// Native code for iOS to the Superposition ANE.
// Handles native listening and events to position variations
@interface iOSLocationExtension : NSObject<CLLocationManagerDelegate, ESTBeaconManagerDelegate> {
    CLLocationManager *locationManager;
    ESTBeaconManager *beaconManager;
    CLBeaconRegion *beaconRegion;
}

@property (nonatomic, strong) ESTBeaconManager *beaconManager;
@property (nonatomic, strong) CLBeaconRegion *beaconRegion;
@property (nonatomic, strong) CLLocationManager *locationManager;
FREObject startGPSListening();
FREObject stopGPSListening();
FREObject startBeaconListening();
FREObject checkBeacons();
FREObject stopBeaconListening();
void stopBeacon();
FREObject startWifiListening();
FREObject stopWifiListening();
void stopWiFi();
void checkNetwork();
void dispatchEvent();


@end

void iOSLocationExtensionContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet);
void iOSLocationExtensionContextFinalizer(FREContext ctx);

void iOSLocationExtensionExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet);
void iOSLocationExtensionExtFinalizer(void* extData);