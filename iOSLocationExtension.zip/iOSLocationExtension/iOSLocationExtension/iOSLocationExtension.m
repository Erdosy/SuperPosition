//
//  iOSLocationExtension.m
//  iOSLocationExtension
//
//  Created by Marcus Andersson on 30/03/16.
//  Copyright © 2016 KjeMar. All rights reserved.
//

#import "iOSLocationExtension.h"
#import <NetworkExtension/NetworkExtension.h>
@import SystemConfiguration.CaptiveNetwork;

iOSLocationExtension *locationExtension;

@implementation iOSLocationExtension

NSString *notImplemented = @"This function is not yet implemented";

FREContext extCtx;

@synthesize locationManager;
@synthesize beaconManager;
@synthesize beaconRegion;
BOOL beaconRanging = false;

- (id)init{
    @autoreleasepool {
        locationExtension = [super init];
        locationExtension.locationManager = [[CLLocationManager alloc] init];
        locationExtension.locationManager.delegate = locationExtension;
        locationExtension.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationExtension.beaconManager = [ESTBeaconManager new];
        locationExtension.beaconManager.delegate = locationExtension;
        locationExtension.beaconRegion = [[CLBeaconRegion alloc] initWithProximityUUID:[[NSUUID alloc] initWithUUIDString:@"B9407F30-F5F8-466E-AFF9-25556B57FE6D"] identifier:@"ranged region"];
        return locationExtension;
    }
}

void dispatchEvent(NSString* const eventCode, NSString* const eventLevel) {
    @autoreleasepool {
        if(extCtx == NULL) {
            return;
        }
        FREDispatchStatusEventAsync(extCtx, (uint8_t*) [eventCode UTF8String], (uint8_t*) [eventLevel UTF8String]);
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    @autoreleasepool {
        NSString *event = @"GPS";
        CLLocation *currentLocation = [locations lastObject];
        NSString *latitude = [NSString stringWithFormat:@"%f", currentLocation.coordinate.latitude];
        NSString *longitude = [NSString stringWithFormat:@"%f", currentLocation.coordinate.longitude];
        NSString *location = [NSString stringWithFormat:@"%@%@%@", latitude, @", ", longitude];
        dispatchEvent(event, location);
    }
}



FREObject startGPSListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {    @autoreleasepool {

    
        [locationExtension.locationManager requestWhenInUseAuthorization];
        [locationExtension.locationManager requestAlwaysAuthorization];
        [locationExtension.locationManager startUpdatingLocation];
    
    }
    return nil;
}

FREObject stopGPSListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        [locationExtension.locationManager stopUpdatingLocation];
    }
    return nil;
}



FREObject startBeaconListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    
    @autoreleasepool {
        
        [locationExtension.beaconManager requestAlwaysAuthorization];
        [locationExtension.beaconManager startMonitoringForRegion:locationExtension.beaconRegion];
        
    }
    return nil;
}

-(void)beaconManager:(id)manager didRangeBeacons:(NSArray<CLBeacon *> *)beacons inRegion:(CLBeaconRegion *)region {
    @autoreleasepool {
    
        NSString *event = @"Beacon";
    
        CLBeacon *nearestBeacon = beacons.firstObject;

        if(nearestBeacon) {
            NSNumber *major = nearestBeacon.major;
            NSNumber *minor = nearestBeacon.minor;
        
            NSString *code = [NSString stringWithFormat:@"%@%@%@", [major stringValue], @",", [minor stringValue]];
            dispatchEvent(event, code);
        }
    }
}

-(void)beaconManager:(id)manager didDetermineState:(CLRegionState)state forRegion:(CLBeaconRegion *)region {
    if([region isKindOfClass:[CLBeaconRegion class]] && state == CLRegionStateInside && !beaconRanging) {
        [self beaconManager:manager didEnterRegion:region];
    }
}

-(void)beaconManager:(id)manager didEnterRegion:(CLBeaconRegion *)region {
    [locationExtension.beaconManager startRangingBeaconsInRegion:region];
    beaconRanging = true;
}


FREObject checkBeacons(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        NSString *event = @"Beacon";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}

FREObject stopBeaconListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        stopBeacon();
    }
    return nil;
}

-(void)beaconManager:(id)manager didExitRegion:(CLBeaconRegion *)region {
    @autoreleasepool {
        stopBeacon();
    }
}

void stopBeacon() {
    @autoreleasepool {
        [locationExtension.beaconManager stopRangingBeaconsInRegion:locationExtension.beaconRegion];
        NSString *event = @"Beacon Exit";
        NSString *code = @"Beacon is out of range or listening stopped";
        dispatchEvent(event, code);
        beaconRanging = false;
    }
}

FREObject startWifiListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), //center
                                        CFBridgingRetain(locationExtension), // observer
                                        networkChanged, //callback
                                        CFSTR("com.apple.system.config.network_change"), // event name
                                        NULL, // object
                                        CFNotificationSuspensionBehaviorDeliverImmediately);
        checkNetwork();
    }
    return nil;
}

static void networkChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    checkNetwork();
}

void checkNetwork() {
    @autoreleasepool {
        NSString *event = @"WiFi";
        NSString *ssid;
        NSArray *interFaceNames = CFBridgingRelease(CNCopySupportedInterfaces());
        for (NSString *name in interFaceNames) {
            NSDictionary *info = (__bridge_transfer id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)name);
            
            if (info[@"SSID"]) {
                ssid = info[@"SSID"];
                dispatchEvent(event, ssid);
            } else {
                stopWiFi();
            }
        }
    }
}


FREObject stopWifiListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        
        CFNotificationCenterRemoveObserver(CFNotificationCenterGetDarwinNotifyCenter(), CFBridgingRetain(locationExtension), CFSTR("com.apple.system.config.network_change"), NULL);
        
        stopWiFi();
    }
    return nil;
}

void stopWiFi() {
    @autoreleasepool {
        NSString *event = @"Wifi Exit";
        NSString *code = @"Lost connection with WiFi or listening stopped";
        dispatchEvent(event, code);    }
    
}

@end

void iOSLocationExtensionContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
    @autoreleasepool {
        extCtx = ctx;
        *numFunctionsToTest = 7;
        FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * (*numFunctionsToTest));
        
        func[0].name = (const uint8_t*) "ffiStartGPSListening";
        func[0].functionData = NULL;
        func[0].function = &startGPSListening;
        
        func[1].name = (const uint8_t*) "ffiStartBeaconListening";
        func[1].functionData = NULL;
        func[1].function = &startBeaconListening;
        
        func[2].name = (const uint8_t*) "ffiCheckBeacons";
        func[2].functionData = NULL;
        func[2].function = &checkBeacons;
        
        func[3].name = (const uint8_t*) "ffiStopBeaconListening";
        func[3].functionData = NULL;
        func[3].function = &stopBeaconListening;
        
        func[4].name = (const uint8_t*) "ffiStartWifiListening";
        func[4].functionData = NULL;
        func[4].function = &startWifiListening;
        
        func[5].name = (const uint8_t*) "ffiStopWifiListening";
        func[5].functionData = NULL;
        func[5].function = &stopWifiListening;
        
        func[6].name = (const uint8_t*) "ffiStopGPSListening";
        func[6].functionData = NULL;
        func[6].function = &stopGPSListening;
        *functionsToSet = func;
    }
    
}

void iOSLocationExtensionExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet) {
    @autoreleasepool {
        locationExtension = [[iOSLocationExtension alloc] init];
        *extDataToSet = NULL;
        *ctxInitializerToSet = &iOSLocationExtensionContextInitializer;
        *ctxFinalizerToSet = &iOSLocationExtensionContextFinalizer;    }
    
}

void iOSLocationExtensionExtFinalizer(void* extData) { }
void iOSLocationExtensionContextFinalizer(FREContext ctx) { }